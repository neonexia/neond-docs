// Run in a clean application directory with the public SDK installed.
import assert from 'node:assert/strict';
import {setTimeout as delay} from 'node:timers/promises';
import {connect} from '@alini/messaging-core';
const admin = process.env.NEOND_ADMIN_URL || 'http://127.0.0.1:8080';
const prom = process.env.PROMETHEUS_URL || 'http://127.0.0.1:9090';
const grafana = process.env.GRAFANA_URL || 'http://127.0.0.1:3001';
async function json(url, options) {
  const response = await fetch(url, {...options, signal: AbortSignal.timeout(15000)});
  assert.equal(response.ok, true, `${url}: ${response.status} ${await response.clone().text()}`);
  return response.json();
}
async function query(expr) {
  const body = await json(`${prom}/api/v1/query?query=${encodeURIComponent(expr)}`);
  assert.equal(body.status, 'success');
  return body.data.result;
}
const client = await connect({
  gatewayUrl: process.env.NEOND_GATEWAY_URL || 'ws://127.0.0.1:8092',
  administration: {url: admin}, credentials: {trustedLocalSubject: 'observability-check'},
});
try {
  const ns = await client.createNamespace(`observe-${Date.now()}`);
  const channel = await ns.ensureChannel('events');
  const reader = channel.subscribe({autoAck: true, startSequence: 1});
  await reader.ready;
  const count = 200;
  const receive = (async () => {
    for (let i=0; i<count; i++) {
      const {value} = await reader.next();
      assert.equal(value.sequence, i+1);
      assert.equal(value.text(), `event-${i}`);
    }
  })();
  for (let i=0; i<count; i++) await channel.publish(`event-${i}`, {guarantee: 'persisted'});
  await Promise.race([receive, delay(30000).then(()=>{throw Error('delivery timeout');})]);
  await reader.close();
  if (process.env.NEOND_VERIFY_TRAFFIC_ONLY === '1') {
    console.log(JSON.stringify({passed:true,published:count,received:count,collectorRequired:false}));
  } else {
  // Keep a sibling on the archive slot: empty-slot reset is tracked separately in GitHub.
  const padding = await client.createNamespace(`padding-${Date.now()}`);
  await padding.ensureChannel('events');
  const closing = await client.createNamespace(`archive-${Date.now()}`);
  const closed = await closing.ensureChannel('events');
  await closed.publish('preserve this', {guarantee: 'persisted'});
  await json(`${admin}/v1/admin/namespaces/${encodeURIComponent(closing.id)}/archive`, {method:'POST',headers:{'content-type':'application/json'},body:'{}'});
  await assert.rejects(closed.publish('closed'), {code: 'namespace_archived'});
  await delay(20000);
  let panels = 0, populated = 0;
  for (const uid of ['neond-messaging', 'neond-storage']) {
    const {dashboard} = await json(`${grafana}/api/dashboards/uid/${uid}`);
    for (const panel of dashboard.panels) for (const target of panel.targets || []) {
      const expr = target.expr.replaceAll('$__rate_interval','1m').replace(/\$(deployment|node|slot|shard)/g,'.*');
      const result = await query(expr); // Any broken PromQL fails the real service request.
      panels++;
      if (result.length) populated++;
    }
  }
  const required = ['alini_gateway_messages','alini_gateway_operation_duration_count','alini_slot_reachable',
    'alini_remote_backlog','alini_node_agent_lease_renewal_duration_count','neond_archive_attempts'];
  for (const metric of required) {
    const result = await query(metric+'{service_namespace="neond-demo"}');
    assert.ok(result.length > 0, `Missing real metric ${metric}`);
  }
  const messages = await query('alini_gateway_messages{service_namespace="neond-demo",direction="publish",guarantee="persisted"}');
  assert.ok(messages.some(x=>Number(x.value[1])>=count), 'Missing confirmed publish measurements');
  console.log(JSON.stringify({passed:true,published:count,received:count,panels,populated}));
  }
} finally { await client.close(); }
