# NeonD with OpenTelemetry and Grafana

A local, vendor-neutral monitoring example. NeonD sends OTLP/HTTP to the standard
OpenTelemetry Collector. The collector writes separate rotating JSON files for
metrics, logs and traces, and exposes metrics for Prometheus. Grafana reads
Prometheus; it does not store telemetry itself.

Requires Docker Compose and enough resources for NeonD, its bundled RustFS/etcd,
the collector, Prometheus and Grafana. This is an isolated local example, not a
secured production monitoring deployment.

```sh
docker compose up -d
```

Open http://localhost:3001 and choose **Dashboards → NeonD**. Anonymous access is
read-only. No Grafana login is needed to view the example; do not expose these
ports or default Grafana administrator credentials to other networks.

- **Messaging health:** freshness, publishing/delivery rates, errors, latency,
  routing, connections, subscriptions, buffering and lease outcomes.
- **Storage and recovery:** slot health, disk budgets, S3 backlog/errors,
  subscription backlog, CPU and archive progress/failures.

Run the [NeonD quickstart](https://neonexia.github.io/neond-docs/getting-started/first-message/)
against this deployment to produce traffic. The admin and gateway endpoints remain
http://localhost:8080 and ws://localhost:8092. Allow about 15 seconds for collection
and scraping; rate panels need at least two samples. Idle or never-used error
instruments may have no data. No data is not proof of health.

Inspect telemetry:

```sh
docker compose logs collector
docker compose cp collector:/data ./telemetry
```

The files are `metrics.json`, `logs.json` and `traces.json` in OTLP JSON format.
Each rotates at 20 MB with two backups. They are diagnostic samples, not a lossless
audit trail. Prometheus keeps 24 hours of metrics in its named volume. This example
does not install Loki or Tempo; Grafana shows metrics, while logs/traces stay in files.

Stop without deleting data: `docker compose down`. Remove this example's data
when finished: `docker compose down -v` (deletes both messages and monitoring data).
Change host ports with NEOND_ADMIN_PORT, NEOND_GATEWAY_PORT, GRAFANA_PORT or
PROMETHEUS_PORT if another deployment is running.

## Connect an existing deployment

Copy `services.telemetry` from `neond.yaml` into your deployment configuration,
using an HTTP(S) endpoint reachable by each NeonD process. Restart/redeploy services
to apply it. The endpoint is the collector base URL, without `/v1/metrics`.
NeonD uses OTLP/HTTP and appends the metrics/logs/traces paths; it does not use the
gRPC receiver on port 4317. Selecting this external endpoint prevents the local
NeonD bundle from starting its own loopback collector.

The YAML enables all signals and uses `serviceNamespace: neond-demo` as the
Grafana deployment filter. Use distinct namespaces for distinct deployments.
Keep file exporters separate per signal. The provided Prometheus exporter uses
`UnderscoreEscapingWithoutSuffixes`: dots become underscores, with no added type
or unit suffixes. Dashboard queries rely on this choice. Histograms retain their
`_bucket`, `_sum` and `_count` series.

Import either JSON dashboard into an existing Grafana and select your Prometheus
data source. Preserve the supplied metric translation and resource labels, or
adapt queries to your pipeline. Node/slot/shard filters apply only to storage
panels with those labels; global gateway/archive panels cannot be sliced by labels
NeonD does not emit. There are no channel labels. Some legacy metric names retain
`alini`; they are NeonD instruments, not an Alini service dependency.

For a hosted backend, replace or add a collector exporter in the relevant pipeline
and supply that exporter's endpoint and credentials according to its vendor's
instructions. NeonD's OTLP/HTTP endpoint remains the same. Authentication and
private-CA settings for a remote collector are not exposed as first-class fields
in NeonD's deployment YAML; do not assume an arbitrary TLS/header YAML field works.
Use a protected local collector to handle the vendor connection. The HTTP-only
Compose network here is suitable for a trusted local demonstration.

Metrics and dashboards are Apache-2.0 NeonD configuration artifacts. Referenced
third-party images have their own licenses; they are pulled from their publishers,
not redistributed inside this download. Versions are pinned for reproducibility,
not a security-maintenance guarantee.

The local bundle has no per-slot capacity-budget assignments, so **Storage
admission** and **Local storage budget used** show no data there. They become
available on distributed nodes configured with slot budgets. Disk free space and
S3 backlog remain useful locally.

Known alpha issue: archiving the last namespace on a slot can stop the local bundle
([#25](https://github.com/neonexia/neond/issues/25)). The example verifier keeps
another namespace on that slot; it does not claim to qualify empty-slot reset.

## Maintainer qualification

From the NeonD checkout, `bash scripts/verify-observability.sh /tmp/new-results`
creates a separate Compose project, installs the public SDK into a clean directory,
verifies exact message delivery and every dashboard query, stops the collector,
verifies messaging still works and Prometheus reports the scrape down, then verifies
fresh metrics return after restart. All three signal files must contain JSON records.
The runner removes only its own project and volumes. CI runs this qualification when
the example or runner changes. It does not qualify every monitoring backend.
